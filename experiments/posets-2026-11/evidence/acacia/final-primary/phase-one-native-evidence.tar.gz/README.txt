Exact native TSVs and memory sidecars from the completed 15-arm, 1524-case
Acacia campaign. Data bytes, float strings and native labels are unchanged.
17-second strict-wall scoring; 8 GiB/no swap. All unsolved cost34s PAR2.
25 native MEMOUT outcomes are distinct from70 OOM-kill-observed invocations:
45 affected invocations retain their native TIMEOUT labels.
Each of10 affected arms has the same7 instances; five arms have no OOM kills.
The new focused default optimization is absent from this phase-one dataset.

Verify30 data files with SHA256SUMS. The archive has32 regular members total.
Summary SHA256: 2bd0a88d55a0ad611f7cdcac7372f25f8b807bedb2cf47946133c2f499ad0b04
Frozen manifest SHA256: 99a05fd894b5994d86759aebe56a42846a820019e1431b86e18639cce034f9ec
No corpus, operation captures, executable, build tree or unrelated WIP is included.
