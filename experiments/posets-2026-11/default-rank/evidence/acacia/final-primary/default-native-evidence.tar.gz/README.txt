Exact native TSVs and memory sidecars from the completed two-arm, 1524-case
Acacia default-rank campaign. Native bytes, float strings and labels unchanged.
Baseline-default Posets789bf99; optimized-default Posets30e6685.
17-second strict-wall scoring; 8 GiB/no swap. All unsolved cost34s PAR2.
Native MEMOUT labels and kernel OOM-kill events are separate observations;
the companion table/event audit retains both without relabelling/rescoring.
This is a separate campaign from the preceding15-arm backend comparison.

Verify4 data files with SHA256SUMS. The archive has6 regular members total.
Frozen manifest SHA256: 548ee0e77b9518a9f96a5f187b8f761966399509607c4fc393fa94a58e1cc5bb
No corpus, operation captures, executable, build tree or unrelated WIP is included.
